import numpy as np

from gefest.core.geometry.geometry_2d import Geometry2D
from gefest.core.opt.setup import Setup
from gefest.core.structure.domain import Domain
from gefest.core.structure.structure import Structure


"""
::TODO::
Rewrite corresponding to new GEFEST logic
like a synthetic examples
"""

def test_fast():
    pass